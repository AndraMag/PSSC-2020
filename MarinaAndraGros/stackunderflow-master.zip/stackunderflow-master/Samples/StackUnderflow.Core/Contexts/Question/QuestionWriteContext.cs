﻿using System;
using System.Collections.Generic;
using System.Linq;
using LanguageExt;
using StackUnderflow.Domain.Schema.Backoffice.CreateTenantOp;
using StackUnderflow.EF.Models;
using static LanguageExt.Prelude;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Question
{

    public class QuestionWriteContext
    {
        public ICollection<Post>  Question { get; }
        public ICollection<User> Users { get; }

        public QuestionWriteContext( ICollection<Post> question, ICollection<User> users)
        {
            Question = question ?? new List<Post>(0);
            Users = users ?? new List<User>(0);
        }
    }
}
