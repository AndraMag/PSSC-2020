﻿using LanguageExt;
using StackUnderflow.Domain.Core.Contexts.Question.SendConfirmationQuestion;
using static StackUnderflow.Domain.Core.Contexts.Question.SendConfirmationQuestion.ConfirmationQuestionResult;
using System;
using System.Collections.Generic;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Question
{
    public class QuestionDependencies
    {
        public Func<string> GenerateConfirmationToken { get; set; }
        public Func<ConfirmationLetter, TryAsync<ConfirmationAcknowledgement>> SendConfirmationEmail { get; set; }
    }
}
