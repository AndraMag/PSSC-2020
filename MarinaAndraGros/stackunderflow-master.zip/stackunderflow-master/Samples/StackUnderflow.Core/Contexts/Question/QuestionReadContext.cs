﻿using System;
using System.Collections.Generic;
using System.Linq;
using LanguageExt;
using StackUnderflow.Domain.Schema.Backoffice.CreateTenantOp;
using StackUnderflow.EF.Models;
using static LanguageExt.Prelude;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Question
{
    public class QuestionReadContext
    {
        public IEnumerable<Post> Question { get; }
        public IEnumerable<User> Users { get; }

        public QuestionReadContext(IEnumerable<Post> question, IEnumerable<User> users)
        {
            Question = question;
            Users = users;
        }
    }
}
