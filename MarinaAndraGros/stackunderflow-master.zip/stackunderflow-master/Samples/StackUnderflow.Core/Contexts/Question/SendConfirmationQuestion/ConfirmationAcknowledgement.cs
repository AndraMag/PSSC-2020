﻿namespace StackUnderflow.Domain.Core.Contexts.Question
{
    public class ConfirmationAcknowledgement
    {
        public ConfirmationAcknowledgement(string receipt)
        {
            Receipt = receipt;
        }
        public string Receipt { get; private set; }
    }
}