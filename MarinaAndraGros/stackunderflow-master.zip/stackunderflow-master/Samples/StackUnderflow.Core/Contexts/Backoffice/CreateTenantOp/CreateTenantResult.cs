﻿using System;
using System.Collections.Generic;
using System.Text;
using Access.Primitives.Extensions.Cloning;
using Access.Primitives.IO;
//using CSharp.Choices;
using LanguageExt;
using Microsoft.AspNetCore.Mvc;
using StackUnderflow.EF.Models;

namespace StackUnderflow.Domain.Schema.Backoffice.CreateTenantOp
{
    [AsChoice]
    public static partial class CreateTenantResult
    {
        public interface ICreateTenantResult : IDynClonable
        {
            // Microsoft.AspNetCore.Mvc.IActionResult Match(Func<object, Microsoft.AspNetCore.Mvc.IActionResult> p1, Func<Exception, Microsoft.AspNetCore.Mvc.ObjectResult> p2, Func<Exception, Microsoft.AspNetCore.Mvc.BadRequestObjectResult> p3);
            //IActionResult Match(Func<object, IActionResult> p1, Func<Exception, ObjectResult> p2, Func<Exception, BadRequestObjectResult> p3);
        }
        public static R Match<R>(this ICreateTenantResult self, System.Func<TenantCreated, R> whenTenantCreated, System.Func<TenantNotCreated, R> whenTenantNotCreated, System.Func<InvalidRequest, R> whenInvalidRequest)
        {
            switch ((self))
            {
                case TenantCreated tenantcreated:
                    return whenTenantCreated(tenantcreated);
                case TenantNotCreated tenantnotcreated:
                    return whenTenantNotCreated(tenantnotcreated);
                case InvalidRequest invalidrequest:
                    return whenInvalidRequest(invalidrequest);
                default:
                    throw new System.NotSupportedException("This switch statement should be exhaustive");
            }
        }

        public class TenantCreated : ICreateTenantResult
        {
            public Tenant Tenant { get; }
            public User AdminUser { get; }

            public TenantCreated(Tenant tenant, User adminUser)
            {
                Tenant = tenant;
                AdminUser = adminUser;
            }

            public object Clone() => this.ShallowClone();

        }

        public class TenantNotCreated : ICreateTenantResult
        {
            public string Reason { get; private set; }

            ///TODO
            public object Clone() => this.ShallowClone();
        }

        public class InvalidRequest : ICreateTenantResult
        {
            public string Message { get; }

            public InvalidRequest(string message)
            {
                Message = message;
            }

            ///TODO
            public object Clone() => this.ShallowClone();
        }
    }
}
