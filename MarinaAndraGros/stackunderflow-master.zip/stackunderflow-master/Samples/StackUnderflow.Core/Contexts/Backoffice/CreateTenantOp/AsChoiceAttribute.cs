﻿using System;

namespace StackUnderflow.Domain.Schema.Backoffice.CreateTenantOp
{
    internal class AsChoiceAttribute : Attribute
    {
    }
}