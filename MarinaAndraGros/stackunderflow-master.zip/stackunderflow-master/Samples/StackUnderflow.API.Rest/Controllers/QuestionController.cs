﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Access.Primitives.Extensions.ObjectExtensions;
using Access.Primitives.IO;
using Microsoft.AspNetCore.Mvc;
using StackUnderflow.Domain.Core;
using StackUnderflow.Domain.Core.Contexts;
using StackUnderflow.Domain.Core.Contexts.Question;
using StackUnderflow.Domain.Core.Contexts.Question.CreateQuestion;
using StackUnderflow.Domain.Core.Contexts.Question.SendConfirmationQuestion;
using StackUnderflow.EF.Models;
using Access.Primitives.EFCore;
using LanguageExt;
using Microsoft.AspNetCore.Http;
using Orleans;
using GrainInterfaces;

namespace StackUnderflow.API.Rest.Controllers
{
    [ApiController]
    [Route("questions")]
    public class QuestionController : ControllerBase
    {
        private readonly IInterpreterAsync _interpretor;

        public QuestionController(IInterpreterAsync interpreter)
        {
            _interpretor = interpreter;
        }
    [HttpPost("{questionId}/reply")]
    public IActionResult CreateReply(int questionId)
        {
            return Ok();
        }
    }


}
