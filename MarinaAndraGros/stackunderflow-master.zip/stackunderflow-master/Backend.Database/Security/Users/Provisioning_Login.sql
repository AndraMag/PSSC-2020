﻿CREATE LOGIN [Provisioning] WITH PASSWORD = 'td:zwgldymv{fmjun~QatdmcmsFT7_&#$!~<m1|agmtkotxw'
